from django.db import models
class Information(models.Model):
    Criminals=models.CharField(max_length=50,primary_key=True,default="")
    Gender = models.CharField(max_length=2,default="")
    Ethnicity = models.CharField(max_length=5,default="")
    Birthplace=models.CharField(max_length=100,default="")
    Accusation = models.CharField(max_length=100,default="")
    Courts=models.CharField(max_length=100,default="")

class Datatext(models.Model):
    Id = models.AutoField(primary_key=True)
    Content = models.TextField(max_length=20000,default="")
    Unique =models.CharField(max_length=255,default="",unique=True)
    Criminals = models.CharField(max_length=50, default="空")
    StartTime = models.CharField(max_length=15, default="1900-01-01")
    OverTime = models.CharField(max_length=15, default="2099-12-31")
    Keywords= models.CharField(max_length=50, default="空")
    Page= models.IntegerField(default=0)
    Courts=models.CharField(max_length=1000,default="")
class Tempsave(models.Model):
    Content = models.TextField(max_length=20000, default="")
# Create your models here.
    # 数据库迁移 命令(建议一起执行)
    # python manage.py makemigrations
    # python manage.py migrate
    # 每次对models.py文件操作,都尽量执行迁移命令
